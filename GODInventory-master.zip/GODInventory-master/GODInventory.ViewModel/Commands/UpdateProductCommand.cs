﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GODInventory.Commands
{
    class UpdateProductCommand 
    {
        #region Fields

        // Member variables
        //private readonly ProductsViewModel m_ViewModel;

        #endregion

        #region Constructor

        //public UpdateProductCommand(ProductsViewModel viewModel)
        //{
        //    m_ViewModel = viewModel;
        //}
        #endregion
    }
}
