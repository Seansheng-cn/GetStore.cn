# GODInventory
Edi order and product management system, for Janpa FRV

## 建立环境
1. .Net frameword 4.5
2. 请安装微软报表组件SQLSysClrTypes.msi 和ReportViewer.msi。
   下载地址 https://www.microsoft.com/zh-tw/download/details.aspx?id=35747
   
## 建立数据库
  mysql, utf8 
  库名： god_inventory
