﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GODInventory.MyLinq
{

    public  class v_receivedorder 
    {

        public int id受注データ { get; set; }

        public int 店舗コード { get; set; }

        public int 伝票番号 { get; set; }

    }

}
